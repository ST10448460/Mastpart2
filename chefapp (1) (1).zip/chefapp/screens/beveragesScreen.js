import React, { useState } from 'react';
import { View, Text, TouchableOpacity, TextInput, Image, StyleSheet, FlatList, Button, SafeAreaView } from 'react-native';

const beveragesScreen = ({ navigation }) => {
  const [searchText, setSearchText] = useState('');
  const [dishes, setDishes] = useState([
    { name: 'Cocoa or Chocolate', price: 'R200', img: 'https://www.fifteen.net/wp-content/uploads/2022/04/cacao-chocolate-hot.jpg' },
    { name: 'Cidars', price: 'R100', img: 'https://www.fifteen.net/wp-content/uploads/2022/04/cider-drinks.jpg' },
    { name: 'Non-Alcoholic drinks', price: 'R150', img: 'https://www.fifteen.net/wp-content/uploads/2022/04/free-alcoholic-beverages.jpg' },
    { name: 'Juices', price: 'R50', img: 'https://www.fifteen.net/wp-content/uploads/2022/04/fruit-juices-drinks.jpg' }
  ]);
  
const [menuItem, setMenuItem] = useState({
  name: '',
  price: '',
  image: '',
  course: ''
});

const[menuItems, setMenuItems] = useState([])
const handleAddItem = () => {
  if (menuItem.name && menuItem.price && menuItem.image && menuItem.course) {
    setMenuItems([...menuItems, menuItem]);
    setMenuItem({
      name: '',
      price: '',
      image: '',
      course: ''
    });
  }
};

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backButton}>Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerText}>Beverages</Text>
       
      </View>
      <View style={styles.searchContainer}>
        <TextInput 
          style={styles.searchInput} 
          placeholder="Hinted search text" 
          value={searchText}
          onChangeText={setSearchText}
        />
      </View>
      <FlatList
        data={dishes.filter(dish => dish.name.toLowerCase().includes(searchText.toLowerCase()))}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.meal}>
            <Image source={{ uri: item.img }} style={styles.mealImage} />
            <Text style={styles.mealTitle}>{item.name} {item.price}</Text>
          </View>
        )}
        numColumns={2}
        columnWrapperStyle={styles.meals}
      />
      <SafeAreaView>
        <View style={{ padding: 20 }}>
          <Text>Add Menu Item</Text>
          <TextInput
            value={menuItem.name}
            onChangeText={(text) => setMenuItem({ ...menuItem, name: text })}
            placeholder="Enter menu item name"
            style={{ height: 40, borderColor: 'gray', borderWidth: 1 }}
          />
          <TextInput
            value={menuItem.price}
            onChangeText={(text) => setMenuItem({ ...menuItem, price: text })}
            placeholder="Enter menu item price"
            style={{ height: 40, borderColor: 'gray', borderWidth: 1 }}
            keyboardType="numeric"
          />
          <TextInput
            value={menuItem.image}
            onChangeText={(text) => setMenuItem({ ...menuItem, image: text })}
            placeholder="Enter menu item image URL"
            style={{ height: 40, borderColor: 'gray', borderWidth: 1 }}
          />
          
          <Button title="Add" onPress={handleAddItem} />
        </View>
        <FlatList
          data={menuItems}
          renderItem={({ item }) => (
            <TouchableOpacity style={{ padding: 20, borderColor: 'gray', borderBottomWidth: 1 }}>
              <Text>{item.name}</Text>
              <Text>Price: ${item.price}</Text>
              <Image source={{ uri: item.image }} style={{ width: 100, height: 100 }} />
              <Text>Course: {item.course}</Text>
            </TouchableOpacity>
          )}
          keyExtractor={(item) => item.name}
        />
      </SafeAreaView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f0f0f0',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  backButton: {
    fontSize: 16,
    color: '#007BFF',
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
 
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 16,
  },
  searchInput: {
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    padding: 8,
  },
  meals: {
    justifyContent: 'space-around',
  },
  meal: {
    width: '45%',
    backgroundColor: '#fff',
    padding: 8,
    borderRadius: 8,
    marginBottom: 16,
  },
  mealImage: {
    width: '100%',
    height: 100,
    borderRadius: 8,
  },
  mealTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    marginVertical: 8,
  },
});

export default beveragesScreen;