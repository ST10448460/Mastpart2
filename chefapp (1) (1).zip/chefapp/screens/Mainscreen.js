import React, { useState } from 'react';
import { View, Text, TouchableOpacity, TextInput, Image, StyleSheet, FlatList, Button,SafeAreaView } from 'react-native';
import { Alert } from 'react-native';


const MainScreen = ({ navigation }) => {
  const [searchText, setSearchText] = useState('');
  const [dishes, setDishes] = useState([
    { name: 'Chicken and Roasted Red Pepper Roll-ups R300', description: 'Create a gourmet chicken dish by stuffing with goat cheese, arugula, and peppers.', img: 'https://www.bhg.com/thmb/y_7bpKCB2sTN5T26eEGmvsVYOxg=/750x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/chicken-red-pepper-rollups-RU217557-1fe22a234f144285bd2718a1a41acde2.jpg' },
    { name: 'SHRIMP AND STEAK R250', description: 'George Bernard Shaw believes love of food is the truest form of love, which is widely embraced by food lovers.', img: 'https://therecipecritic.com/wp-content/uploads/2019/01/skilletsteakandshrimplate-667x1000.jpg' },
    { name: 'Japanese Roast Chicken R350', description: 'Sesame seeds, pepper, garlic, and dried orange peel infuse each bite of this Japanese Roast Chicken recipe with warm Asian flavors.', img: 'https://www.bhg.com/thmb/Pw6sYisSxLucOOjB95XKawSPlkU=/750x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/japanese-roast-chicken-RU230026-f6dc26ca10324a28b32fedde4f36f08e.jpg' },
    { name: 'Chicken with Marsala Risotto R400', description: 'This chicken marsala recipe looks like it came from a fancy Italian restaurant, but surprise: this jazzed-up risotto recipe is actually super-doable to recreate in your own kitchen.', img: 'https://www.bhg.com/thmb/Wj5hW9VswOSOmof0RaNIASXhr3M=/750x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/RU195773-3d99cadf7580451bb0cbc2bec1504ea8.jpg' },

  ]);

const [menuItem, setMenuItem] = useState({
  name: '',
  price: '',
  image: '',
  course: ''
});
 
const[menuItems, setMenuItems] = useState([]) 
const handleAddItem = () => {
  if (menuItem.name && menuItem.price && menuItem.image && menuItem.course) {
    setMenuItems([...menuItems, menuItem]);
    setMenuItem({
      name: '',
      price: '',
      image: '',
      course: ''
    });
  }
};

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backButton}>Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerText}>Main</Text>
        
      </View>
      <View style={styles.searchContainer}>
        <TextInput 
          style={styles.searchInput} 
          placeholder="search" 
          value={searchText}
          onChangeText={setSearchText}
        />
      </View>
      <Text style={styles.subtitle}>4 meals found</Text>
      <FlatList
        data={dishes.filter(dish => dish.name.toLowerCase().includes(searchText.toLowerCase()))}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.meal}>
            <Image source={{ uri: item.img }} style={styles.mealImage} />
            <Text style={styles.mealTitle}>{item.name}</Text>
            <Text style={styles.mealDescription}>{item.description}</Text>
          </View>
        )}
      />
      <SafeAreaView>
        <View style={{ padding: 20 }}>
          <Text>Add Menu Item</Text>
          <TextInput
            value={menuItem.name}
            onChangeText={(text) => setMenuItem({ ...menuItem, name: text })}
            placeholder="Enter menu item name"
            style={{ height: 40, borderColor: 'gray', borderWidth: 1 }}
          />
          <TextInput
            value={menuItem.price}
            onChangeText={(text) => setMenuItem({ ...menuItem, price: text })}
            placeholder="Enter menu item price"
            style={{ height: 40, borderColor: 'gray', borderWidth: 1 }}
            keyboardType="numeric"
          />
          <TextInput
            value={menuItem.image}
            onChangeText={(text) => setMenuItem({ ...menuItem, image: text })}
            placeholder="Enter menu item image URL"
            style={{ height: 40, borderColor: 'gray', borderWidth: 1 }}
          />
          
          <Button title="Add" onPress={handleAddItem} />
        </View>
        <FlatList
          data={menuItems}
          renderItem={({ item }) => (
            <TouchableOpacity style={{ padding: 20, borderColor: 'gray', borderBottomWidth: 1 }}>
              <Text>{item.name}</Text>
              <Text>Price: ${item.price}</Text>
              <Image source={{ uri: item.image }} style={{ width: 100, height: 100 }} />
              <Text>Course: {item.course}</Text>
            </TouchableOpacity>
          )}
          keyExtractor={(item) => item.name}
        />
      </SafeAreaView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f0f0f0',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  backButton: {
    fontSize: 16,
    color: '#007BFF',
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 16,
  },
  searchInput: {
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    padding: 8,
  },
  meal: {
    backgroundColor: '#fff',
    padding: 8,
    borderRadius: 8,
    marginBottom: 16,
  },
  mealImage: {
    width: '100%',
    height: 100,
    borderRadius: 8,
  },
  mealTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    marginVertical: 8,
  },
  mealDescription: {
    fontSize: 12,
  },
});

export default MainScreen;