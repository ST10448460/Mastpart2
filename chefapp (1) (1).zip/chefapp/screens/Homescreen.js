import React from 'react';
import { View, Text, TouchableOpacity, TextInput, Image, StyleSheet } from 'react-native';

const Homescreen = ({ navigation }) => {
  return (
     <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>Christoffel's</Text>
      </View>
      <Text style={styles.title}>EXPLORE ALL DIFFERENT CUISINES MADE BY CHRISTOFFEL</Text>
      <View style={styles.searchContainer}>
        <TextInput style={styles.searchInput} placeholder="search" />
      </View>
      <Text style={styles.subtitle}>CATEGORIES</Text>
      <View style={styles.categories}>
        <TouchableOpacity onPress={() => navigation.navigate('Beverages')} style={styles.category}>
        <Text style={styles.categoryIcon}>🍴</Text>
          <Text style={styles.categoryText}>beverage</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Main')} style={styles.category}>
       <Text style={styles.categoryIcon}>🍔</Text>
          <Text style={styles.categoryText}>main</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Desserts')} style={styles.category}>
         <Text style={styles.categoryIcon}>🎂</Text>
          <Text style={styles.categoryText}>desserts</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.subtitle}>4 meals found</Text>
      <View style={styles.meals}>
        <View style={styles.meal}>
          <Image source={{ uri: 'https://www.bhg.com/thmb/y_7bpKCB2sTN5T26eEGmvsVYOxg=/750x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/chicken-red-pepper-rollups-RU217557-1fe22a234f144285bd2718a1a41acde2.jpg' }} style={styles.mealImage} />
          <Text style={styles.mealTitle}>Chicken and Roasted Red Pepper Roll-ups R300</Text>
          <Text style={styles.mealDescription}>Create a gourmet chicken dish by stuffing with goat cheese, arugula, and peppers.</Text>
        </View>
        <View style={styles.meal}>
          <Image source={{ uri: 'https://therecipecritic.com/wp-content/uploads/2019/01/skilletsteakandshrimplate-667x1000.jpg' }} style={styles.mealImage} />
          <Text style={styles.mealTitle}>SHRIMP AND STEAK R250</Text>
          <Text style={styles.mealDescription}>George Bernard Shaw believes love of food is the truest form of love, which is widely embraced by food lovers.</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f0f0f0',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginVertical: 16,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    padding: 8,
  },
  subtitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginVertical: 8,
  },
  categories: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
  },
  category: {
    alignItems: 'center',
  },
  categoryText: {
    fontSize: 14,
  },
  meals: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  meal: {
    width: '45%',
    backgroundColor: '#fff',
    padding: 8,
    borderRadius: 8,
    marginBottom: 16,
  },
  mealImage: {
    width: '100%',
    height: 100,
    borderRadius: 8,
  },
  mealTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    marginVertical: 8,
  },
  mealDescription: {
    fontSize: 12,
  },
  categoryIcon: {
    fontSize: 24,
  },
});


export default Homescreen;